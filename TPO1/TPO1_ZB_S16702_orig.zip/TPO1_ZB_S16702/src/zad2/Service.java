/**
 *
 *  @author Żółkiewski Bartosz S16702
 *
 */

package zad2;


public class Service {
}  
